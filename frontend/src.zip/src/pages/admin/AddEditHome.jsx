import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getHome, createHome, updateHome } from "../../api/homes";
import ErrorList from "../../components/ErrorList";
import { resolveImageUrl } from "../../utils/resolveImageUrl";

const emptyForm = {
  homeName: "",
  homePrice: "",
  homeLocation: "",
  homeRating: "",
  homeDiscription: "",
  photoURL: "", // used as a fallback if no file is chosen
};

export default function AddEditHome() {
  const { homeId } = useParams();
  const editing = Boolean(homeId);
  const navigate = useNavigate();

  const [form, setForm] = useState(emptyForm);
  const [photoFile, setPhotoFile] = useState(null);
  const [filePreview, setFilePreview] = useState("");
  const [errors, setErrors] = useState([]);

  useEffect(() => {
    if (!photoFile) {
      setFilePreview("");
      return undefined;
    }

    const previewUrl = URL.createObjectURL(photoFile);
    setFilePreview(previewUrl);

    return () => URL.revokeObjectURL(previewUrl);
  }, [photoFile]);

  useEffect(() => {
    if (!editing) return;
    getHome(homeId).then((home) => {
      setForm({
        homeName: home.homeName || "",
        homePrice: home.homePrice || "",
        homeLocation: home.homeLocation || "",
        homeRating: home.homeRating || "",
        homeDiscription: home.homeDiscription || "",
        photoURL: home.photoURL || "",
      });
    });
  }, [editing, homeId]);

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  // A freshly-picked file (blob URL, already a valid <img> src as-is) wins
  // over a stored/pasted URL, which may be a backend-relative path that
  // needs resolving against the backend's origin.
  const photoPreview = filePreview || resolveImageUrl(form.photoURL);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrors([]);

    const data = new FormData();
    data.append("homeName", form.homeName);
    data.append("homePrice", form.homePrice);
    data.append("homeLocation", form.homeLocation);
    data.append("homeRating", form.homeRating);
    data.append("homeDiscription", form.homeDiscription);

    if (photoFile) {
      data.append("photo", photoFile);
    } else if (form.photoURL) {
      data.append("photoURL", form.photoURL);
    }

    try {
      if (editing) {
        await updateHome(homeId, data);
      } else {
        await createHome(data);
      }
      navigate("/admin/admin-home-list");
    } catch (err) {
      const message = err.response?.data?.message || "Something went wrong. Please try again.";
      setErrors([message]);
    }
  };

  return (
    <main className="container mx-auto mt-8 rounded-lg bg-white p-8 shadow-md">
      <h1 className="mb-6 text-center text-3xl font-bold text-gray-800">
        {editing ? "Edit Your Home" : "Register Your Home on AirBnB"}
      </h1>

      <form onSubmit={handleSubmit} className="mx-auto max-w-md space-y-4">
        <ErrorList errors={errors} />

        <input
          type="text"
          placeholder="Enter your House Name"
          value={form.homeName}
          onChange={update("homeName")}
          required
          className="w-full rounded-md border px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
        />

        <input
          type="number"
          min="0"
          step="0.01"
          placeholder="Enter price in Rupees"
          value={form.homePrice}
          onChange={update("homePrice")}
          required
          className="w-full rounded-md border px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
        />

        <input
          type="text"
          placeholder="Enter your house location"
          value={form.homeLocation}
          onChange={update("homeLocation")}
          required
          className="w-full rounded-md border px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
        />

        <input
          type="number"
          min="0"
          max="5"
          step="0.1"
          placeholder="Enter rating, e.g. 3.6"
          value={form.homeRating}
          onChange={update("homeRating")}
          required
          className="w-full rounded-md border px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
        />

        <div>
          <label className="mb-1 block text-sm text-gray-600">Upload a photo</label>
          <input
            type="file"
            accept="image/*"
            onChange={(e) => setPhotoFile(e.target.files?.[0] || null)}
            className="w-full rounded-md border px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
          />
        </div>

        <input
          type="url"
          placeholder="...or paste an image URL instead"
          value={form.photoURL}
          onChange={update("photoURL")}
          disabled={Boolean(photoFile)}
          className="w-full rounded-md border px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500 disabled:cursor-not-allowed disabled:bg-gray-100 disabled:text-gray-400"
        />

        {photoPreview && (
          <img
            src={photoPreview}
            alt="Selected home"
            className="h-48 w-full rounded-md object-cover"
            onError={() => setErrors(["The image URL could not be loaded. Please use a direct image link."])}
          />
        )}

        <textarea
          placeholder="Enter your house description"
          value={form.homeDiscription}
          onChange={update("homeDiscription")}
          className="w-full rounded-md border px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
        />

        <button
          type="submit"
          className="w-full rounded-md bg-red-500 py-2 text-white transition duration-300 hover:bg-red-600"
        >
          {editing ? "Update Home" : "Submit"}
        </button>
      </form>
    </main>
  );
}
