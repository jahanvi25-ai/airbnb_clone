import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function NavLink({ to, children }) {
  const { pathname } = useLocation();
  const active = pathname === to;
  return (
    <Link
      to={to}
      className={`relative flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-medium transition duration-200 hover:bg-white/10 ${
        active ? "bg-white/15" : ""
      }`}
    >
      {children}
    </Link>
  );
}

export default function Navbar() {
  const { isLoggedIn, isAdmin, logout } = useAuth();

  return (
    <header className="bg-red-500 text-white shadow-md">
      <nav className="container mx-auto flex items-center justify-between px-4 py-4">
        <ul className="flex items-center gap-1 sm:gap-3">
          <li>
            <NavLink to="/">Home</NavLink>
          </li>

          {!isLoggedIn && (
            <>
              <li>
                <NavLink to="/login">Login</NavLink>
              </li>
              <li>
                <NavLink to="/signup">Signup</NavLink>
              </li>
            </>
          )}

          {isLoggedIn && isAdmin && (
            <>
              <li>
                <NavLink to="/admin/add-home">Add Home</NavLink>
              </li>
              <li>
                <NavLink to="/admin/admin-home-list">Admin's List</NavLink>
              </li>
            </>
          )}

          {isLoggedIn && !isAdmin && (
            <>
              <li>
                <NavLink to="/store/favourite-list">Favourite List</NavLink>
              </li>
              <li>
                <NavLink to="/store/bookings">Bookings</NavLink>
              </li>
            </>
          )}
        </ul>

        {isLoggedIn && (
          <button
            onClick={logout}
            className="rounded-md border border-white/50 px-4 py-2 text-sm font-semibold transition duration-200 hover:-translate-y-0.5 hover:bg-white hover:text-red-500"
          >
            Logout
          </button>
        )}
      </nav>
    </header>
  );
}
