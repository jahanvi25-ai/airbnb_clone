import { useEffect, useState } from "react";
import HomeCard from "../components/HomeCard";
import { useAuth } from "../context/AuthContext";
import { getHomes } from "../api/homes";
import * as favouritesApi from "../api/favourites";

export default function Home() {
  const { isLoggedIn, isAdmin } = useAuth();
  const [homes, setHomes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getHomes()
      .then(setHomes)
      .finally(() => setLoading(false));
  }, []);

  const handleAddFavourite = async (homeId) => {
    try {
      await favouritesApi.addFavourite(homeId);
    } catch (err) {
      console.error("Could not add favourite", err);
    }
  };

  if (loading) return null;

  return (
    <main className="container mx-auto px-4 py-8">
      <h2 className="mb-8 text-center text-3xl font-bold text-red-500">
        Here are Suggested homes for you:
      </h2>

      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {homes.map((home) => (
          <HomeCard
            key={home._id}
            home={home}
            actions={
              // Guests get the favourite button; hosts manage listings from
              // the admin list instead, so it's hidden here for them.
              isLoggedIn && !isAdmin ? (
                <button
                  onClick={() => handleAddFavourite(home._id)}
                  className="rounded bg-pink-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-pink-700"
                >
                  Add to favourite
                </button>
              ) : null
            }
          />
        ))}
      </ul>
    </main>
  );
}
