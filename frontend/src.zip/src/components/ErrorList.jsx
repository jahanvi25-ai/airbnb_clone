export default function ErrorList({ errors }) {
  if (!errors || errors.length === 0) return null;

  return (
    <div
      className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-red-700"
      role="alert"
    >
      <strong className="font-bold">Error!</strong>
      <ul className="mt-1 list-inside list-disc text-sm">
        {errors.map((error, i) => (
          <li key={i}>{error}</li>
        ))}
      </ul>
    </div>
  );
}
