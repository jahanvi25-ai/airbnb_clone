import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getHome } from "../api/homes";
import * as favouritesApi from "../api/favourites";
import { useAuth } from "../context/AuthContext";
import { resolveImageUrl } from "../utils/resolveImageUrl";

export default function HomeDetail() {
  const { homeId } = useParams();
  const navigate = useNavigate();
  const { isLoggedIn } = useAuth();
  const [home, setHome] = useState(null);

  useEffect(() => {
    getHome(homeId)
      .then(setHome)
      .catch(() => navigate("/"));
  }, [homeId, navigate]);

  if (!home) return null;

  return (
    <main className="container mx-auto mt-10 px-4">
      <section className="mx-auto max-w-3xl overflow-hidden rounded-lg bg-white shadow-lg">
        <img
          src={resolveImageUrl(home.photoURL)}
          alt={home.homeName}
          className="h-80 w-full object-cover"
        />

        <div className="p-6">
          <h1 className="mb-4 text-3xl font-bold text-gray-800">{home.homeName}</h1>

          <p className="mb-2 text-lg text-gray-700">
            <span className="font-semibold">Location:</span> {home.homeLocation}
          </p>
          <p className="mb-2 text-lg text-gray-700">
            <span className="font-semibold">Rating:</span> {Number(home.homeRating).toFixed(1)}
          </p>
          {home.homeDiscription && (
            <p className="mb-2 text-gray-600">{home.homeDiscription}</p>
          )}
          <p className="mb-6 text-xl font-bold text-green-600">Rs {home.homePrice} / night</p>

          <div className="flex justify-between">
            <div className="flex gap-3">
              <Link to="/" className="rounded bg-gray-600 px-2 py-1 text-white">
                Back
              </Link>
              <Link to="/store/reserve" className="rounded bg-green-700 px-2 py-1 text-white">
                Reserve
              </Link>
            </div>

            {isLoggedIn && (
              <button
                onClick={() => favouritesApi.addFavourite(home._id)}
                className="rounded bg-pink-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-pink-700"
              >
                Add to favourite
              </button>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}
