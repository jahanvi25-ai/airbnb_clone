import { Link } from "react-router-dom";
import { resolveImageUrl } from "../utils/resolveImageUrl";

// `actions` is whatever buttons/links this particular page needs under the
// card (Detail + Favourite on the guest list, Edit + Delete on the admin
// list, etc) — kept as a prop instead of forking this component three ways.
export default function HomeCard({ home, actions }) {
  return (
    <li className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-lg">
      <img
        src={resolveImageUrl(home.photoURL)}
        alt={home.homeName}
        className="h-52 w-full object-cover"
      />

      <div className="p-5">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-gray-900">{home.homeName}</h2>
            <p className="mt-1 text-sm font-medium text-gray-500">{home.homeLocation}</p>
          </div>

          <span className="shrink-0 rounded-full bg-yellow-100 px-3 py-1 text-sm font-bold text-yellow-700">
            {Number(home.homeRating).toFixed(1)}
          </span>
        </div>

        <div className="mb-5 flex items-center justify-between border-t border-gray-100 pt-4">
          <p className="text-lg font-bold text-green-700">Rs {home.homePrice}</p>
          <p className="text-sm text-gray-500">per night</p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to={`/store/home-detail/${home._id}`}
            className="rounded bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700"
          >
            Detail
          </Link>
          {actions}
        </div>
      </div>
    </li>
  );
}
