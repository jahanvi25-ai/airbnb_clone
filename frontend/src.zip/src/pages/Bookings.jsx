export default function Bookings() {
  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-800">This is the Bookings page</h1>
    </main>
  );
}
