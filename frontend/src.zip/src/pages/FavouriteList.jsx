import { useEffect, useState } from "react";
import HomeCard from "../components/HomeCard";
import * as favouritesApi from "../api/favourites";

export default function FavouriteList() {
  const [favourites, setFavourites] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    favouritesApi
      .getFavourites()
      .then(setFavourites)
      .finally(() => setLoading(false));
  }, []);

  const handleRemove = async (homeId) => {
    // The remove endpoint returns the raw favourites array (just IDs, not
    // populated home documents), so re-fetch the populated list instead of
    // rendering the response directly.
    await favouritesApi.removeFavourite(homeId);
    const updated = await favouritesApi.getFavourites();
    setFavourites(updated);
  };

  if (loading) return null;

  return (
    <main className="container mx-auto mt-10 rounded bg-white p-8 shadow-lg">
      <h2 className="mb-6 text-center text-3xl font-bold text-red-500">
        Here are our Favourites:
      </h2>

      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {favourites.map((home) => (
          <HomeCard
            key={home._id}
            home={home}
            actions={
              <button
                onClick={() => handleRemove(home._id)}
                className="cursor-pointer rounded bg-red-950 px-2 py-1 text-lg text-white"
              >
                Remove
              </button>
            }
          />
        ))}
      </ul>
    </main>
  );
}
